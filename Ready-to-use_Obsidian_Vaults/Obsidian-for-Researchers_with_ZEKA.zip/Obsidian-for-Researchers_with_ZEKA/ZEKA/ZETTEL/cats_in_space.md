---
Created: 2025-05-05 14:43
tags:
  - p1/lit_review
---
### Input

Colleagues story about his cat. 
### Reference

My idea based on his story.
### Output

Idea for introduction: Cats in space are funny.
### Link
[[picture_cats_in_space]] 
[[New_Note]] 
[[picture_cats_in_space]] 