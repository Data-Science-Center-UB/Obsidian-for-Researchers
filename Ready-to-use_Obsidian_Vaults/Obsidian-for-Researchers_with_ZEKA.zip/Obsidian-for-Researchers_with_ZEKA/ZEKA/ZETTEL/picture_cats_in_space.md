---
Created: 2025-05-05 14:47
tags:
  - p1/lit_review
---
### Input
Prompt: Cats in space are funny.
### Reference
ChatGPT Image 9. Apr. 2025, 19_24_48

### Output
![](ChatGPT%20Image%209.%20Apr.%202025,%2019_24_48.png)
### Link
