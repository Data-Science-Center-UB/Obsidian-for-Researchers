[Path to local Obsidian Vault](<C:\Users\name\Desktop\ObsidianLocal\MyVault>)

**06/05/2025**
Set-up Zettelkasten
Installed Better BibTeX in Zotero
In Better BibTeX insert citation key: "z." + authEtal2(creator = "*", initials = false, sep = ".").fold + year

Installed "Zotero Integration" in Obsidian
Zotero Integration "Note Import Location" set to "ZEKA/SOURCE_NOTES"

Settings → Zotero Integration → Citation Format → Add Citation Format → American Political Science Association 

Import Formats → Add Import Format:
Name: Add Source Notes  
Output Path: ZEKA/SOURCE_NOTES/{{citekey}}.md  
Image Output Path: BACKEND/ATTACHMENT/{{citekey}}/  
Template File: BACKEND/TEMPLATES/Zotero_Template.md  
Bibliography Style: American Political Science Association 

Enabled "Show Backlinks at the bottom of your notes"

**06/05/2025**
Files and links → disabled "Use Wikilinks"
Files and links → enabled "Automatically update internal links"

**05/05/2025** 
Installed community plugins Templater, Dataview and Task.
	Templater: Set folder locations.
	Dataview: Enabled JavaScript queries and inline JavaScript queries.
These plugins are used for the daily note.
New Template for daily note.

**05/05/2025**  
Settings for "Files and Links" have been changed. Attachments are now automatically stored in the ATTACHMENT folder. 