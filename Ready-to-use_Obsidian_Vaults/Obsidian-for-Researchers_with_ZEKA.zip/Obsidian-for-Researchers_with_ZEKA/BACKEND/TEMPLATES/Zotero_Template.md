---
tags: {% if allTags %}{{allTags}}{% endif %}
created: {{importDate|format("YYYY-MM-DD")}}
---

# {{title}}

## Bibliographic Information

**Authors:** {{authors}}

**Reference:** {{bibliography}}
**Zotero Link:** {{pdfZoteroLink}}

{% if abstractNote %}
>[!NOTE]- Abstract
>{{abstractNote}}
{% endif %}

---
<!-- 
Template Note: 
- Highlighted text from Zotero PDFs is displayed in *italic*.
- Comments or notes associated with highlights are displayed in normal (non-italic) text.
- This ensures that you can quickly distinguish between the original highlighted text and your comments.
-->

{% for annotation in annotations -%} 
{%- if annotation.annotatedText -%}
*{{annotation.annotatedText}}* (p.{{annotation.pageLabel}})
{% endif %}
{% if annotation.imageRelativePath %}
![[{{annotation.imageRelativePath}}]]
{% endif %}
{% if annotation.comment %}
{{annotation.comment}}
{% endif %}
{% if annotation.hashTags %}
{{annotation.hashTags}}
{% endif %}
{% endfor %}
