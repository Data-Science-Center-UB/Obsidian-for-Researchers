```dataview
LIST
FROM #p1/lit_review
```
[[2025_paper_cats_gravity_v1]]