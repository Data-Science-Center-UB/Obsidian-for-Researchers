[Path to local Obsidian Vault](<C:\Users\name\Desktop\ObsidianLocal\MyVault>)

**06/05/2025**
Files and links → disabled "Use Wikilinks"
Files and links → enabled "Automatically update internal links"

**05/05/2025** 
Installed community plugins Templater, Dataview and Task.
	Templater: Set folder locations.
	Dataview: Enabled JavaScript queries and inline JavaScript queries.
These plugins are used for the daily note.
New Template for daily note.

**05/05/2025**  
Settings for "Files and Links" have been changed. Attachments are now automatically stored in the ATTACHMENT folder. 