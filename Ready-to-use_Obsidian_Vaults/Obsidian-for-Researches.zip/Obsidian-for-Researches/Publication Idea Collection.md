```dataview
LIST
FROM #test
```
